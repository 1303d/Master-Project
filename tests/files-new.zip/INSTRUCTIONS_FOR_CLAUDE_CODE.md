# Task: v8 dev evaluation on Haiku and Qwen, with a detailed report

From: Dhanush (with Claude Desktop), 2026-10-30.
Goal: choose between prompts v8a and v8, compare Claude Haiku and Qwen on the chosen prompt, and measure
token use, so the team can decide which model runs the 2,000-posting batch for Sprint 4.

Read this whole file before starting. Ask Dhanush before anything marked **ASK**.

## 0. Hard rules (do not break)

1. **Test set:** never extract, score or open test postings. Every command runs on dev only
   (`data/gold/gold_postings_dev.csv`; `evaluate.py --split dev`). The guards you added must stay on.
2. **No changes to scoring.** `evaluate.py` matching (strict, lenient) stays exactly as committed. Only the
   options listed in step 1 may be added to other files.
3. **No changes to gold or prompt files** in this bundle. If something in them looks wrong, report it; do not edit.
4. **One setting per run.** Never change model, prompt, temperature, reasoning format, `--typed` or `--types`
   partway through a run. If a run must restart, it resumes from the cache with identical settings.
5. **Do not start the 2,000-posting batch.** This task ends with the report. **ASK** first.
6. Do **not** copy the older `code_patches` files from Claude Desktop over the repo: the repo already has those
   patches plus your manifest change.

## 1. Setup

1. Copy from this bundle into the repo (check `SHA256SUMS.txt` after copying):
   - `prompts/skill_extraction_v8a.txt`, `prompts/skill_extraction_v8.txt` → `prompts/`
   - `gold/gold_labels_v3_dev_proposed.csv` → `data/gold/` (should already be identical to yours; confirm by hash)
   - `gold/gold_audit_dev_v3_proposed.xlsx` → `data/gold/audit/` (used only in report section 6)
2. **`--types` option in `extract_skills.py`.** The v8 prompts allow only `skill`, `knowledge`, `tool`, but
   `TYPES` (and so `JSON_HINT` and the schema enum) still lists 8 types. Add `--types` (comma list, default = the
   current 8, so old runs and caches are unchanged). The chosen list feeds `TYPES`, the JSON hint, the schema enum
   and the call settings (so it is part of the cache key). v8a and v8 runs use `--typed --types skill,knowledge,tool`.
3. **Manifest guard.** `cache_keys_<run>.csv` is keyed by run name. If a manifest for the same run name exists
   with different call settings, stop with an error (do not overwrite).
4. Add a test for each of 2 and 3 to `tests/`. Run all tests.
5. Commit (message: "v8 prompts, --types, manifest guard"). Record the commit hash for the report.

## 2. Find the exact model IDs and limits (no guessing)

- **Haiku:** use the exact model ID from the earlier Haiku research run (`reports/token_usage.csv` or the
  statements files). If more than one Haiku ID appears, **ASK**.
- **Qwen:** `qwen/qwen3.8-27b` on Groq, same as the v3/v5 runs.
- **Groq limits:** make one cheap call (or read the console Limits page) and record the `x-ratelimit-*` response
  headers: requests per day, tokens per minute, and the tokens-per-day figure from the Limits page.
  Dhanush believes TPD is about 200k; record the real value.

## 3. Runs (all on the 50 dev postings)

Run order matters: Haiku decides the prompt, so Groq quota is spent only on the winning prompt.

| # | Model | Prompt | Flags | Tag |
|---|---|---|---|---|
| H3 | Haiku | v3 | (untyped, as the original baseline) | `v3` (reuse cache if present) |
| H8a | Haiku | v8a | `--typed --types skill,knowledge,tool` | `v8a` |
| H8 | Haiku | v8 | `--typed --types skill,knowledge,tool` | `v8` |
| Q8x | Qwen | winner of the decision rule below | same flags | `v8a` or `v8` |

Qwen v3 already exists (`qwen_qwen3.8-27b_v3`); reuse it, with `--legacy-cache-key` if needed.

**Pre-registered prompt decision rule** (written before seeing results; apply it mechanically, on Haiku, against
`gold_labels_v3_dev_proposed.csv`, same postings):
- Choose **v8** if its strict F1 ≥ v8a's strict F1 **and** its strict precision is no more than 0.02 below v8a's.
- Otherwise choose **v8a**.
Report the numbers either way. Do not adjust the rule after seeing results.

**Qwen run settings:** same as the v3/v5 Qwen runs (temperature 0, `reasoning_format` hidden). Before the run,
set `--delay` from the measured limits: delay ≥ (expected tokens per call ÷ TPM) × 60 s; use the Haiku token counts
as a first estimate and log the real Qwen counts. If the daily token limit is hit, stop cleanly and resume the
next day with identical settings. Note every stop and resume (time, postings done) for the report.

## 4. Scoring

For every run, score with the patched `evaluate.py` (dev split, `--sector-source split`,
`--aliases data/skill_aliases_manual.csv`) against **both** gold files:
`data/gold/gold_labels_v2.csv` and `data/gold/gold_labels_v3_dev_proposed.csv`.

Paired comparisons (`--baseline`, 2,000 bootstrap draws, same postings), against the v3-proposed gold:
- Haiku: v8a vs v3, v8 vs v8a, v8 vs v3
- Qwen: chosen v8x vs v3
- Cross-model: Qwen v8x vs Haiku v8x (same prompt)

If `link_reference.py` output (`skill_links.csv`) is available, also report each main run with `--links`
(traits dropped) as an extra column. Do not replace the main numbers with it.

## 5. Report

Write `reports/v8_dev_evaluation_2026-10-30.md` (markdown, tables, no long prose), plus every table as CSV in
`reports/v8_dev_evaluation_2026-10-30/`. Sections, in this order:

1. **Run manifest.** Commit hash; run dates and times; model IDs; provider; prompt file names and SHA-256; all call
   settings (temperature, reasoning format, typed, types, delay); gold file names and SHA-256; postings scored per
   run; failed postings; stops/resumes.
2. **Main results table.** One row per (model, prompt, gold): postings, gold items, predicted items, P/R/F1 strict,
   P/R/F1 lenient, F1 strict+alias, and F1 with traits dropped (if available). Include the existing Qwen v3/v5 rows.
3. **Paired comparisons.** Every comparison in step 4: baseline F1, this F1, difference, 95% interval, for strict,
   lenient and strict+alias. One line per comparison stating whether the interval contains 0.
4. **Prompt decision.** The pre-registered rule, the numbers it used, and the result.
5. **Per-sector table** (v3-proposed gold, chosen prompt, both models): sector, postings, gold items, P/R/F1 strict
   and lenient. Mark sectors with fewer than 5 postings as "too small to interpret".
6. **Error breakdown** (lenient misses and extras, chosen prompt, both models; also Qwen v5 for comparison).
   Join each miss and extra to `Audit Findings` in the audit workbook by posting `n` and label:
   - misses: on an original gold label (no audit finding) / on a label under REVIEW / on a label the audit added or revised
   - extras: matches a REVIEW candidate / trait / rule-list violation (see section 7) / single word / near-miss wording
     of a missed gold item in the same posting (list these pairs) / other
   - top 10 postings by number of misses on original gold labels, with their misses listed
7. **Instruction-following checks** (count per run, with examples): predictions of "attention to detail" or
   "detail-oriented"; scope duplicates (e.g. "quarter-end close" or "year-end close" next to "month-end close");
   items that literally match an example in prompt rules 9, 10 or 11 (routine duties, industries/settings, outcomes);
   "teamwork"/"team player" counts; evidence-verbatim rate; JSON failures; postings with zero predictions that have gold
   skills (list them, with the raw model answer).
8. **Types.** Distribution of skill / knowledge / tool per run. Export a random sample of 30 typed items per model to
   CSV with posting, item, type, evidence, and an empty `human_check` column (for a human to fill in; do not fill it).
9. **Tokens, limits and cost.** Per model: tokens in and out per posting (mean, median, max); for Qwen, the share of
   output tokens that are hidden reasoning if the API reports it; total calls and retries; 429s. Groq limits as
   measured in step 2. Projection for 2,000 postings: total tokens; days needed on Groq free tier at the measured
   TPD; Haiku cost using the current price from Anthropic's pricing page (cite the URL and the date read; do not use
   remembered prices), with and without the Message Batches API discount if it applies to this key.
10. **Independence check.** Run `src/bias_check.py` if it exists and report its output. If the gold has a
    `suggested_skills` column, split gold labels into (a) accepted LLM suggestions and (b) labels humans added or
    rewrote, and report recall for each model on (a) and (b) separately. A large gap for Haiku but not Qwen would
    indicate shared bias with the suggesting models.
11. **Ten example postings.** For 10 dev postings (spread across sectors, chosen by `n` order, not by score): gold
    labels, Haiku predictions, Qwen predictions, side by side, with matches marked.
12. **Facts for the batch decision.** A short table, not a recommendation: per model, F1 (strict, lenient), the
    cross-model interval, projected days or cost for 2,000 postings, and the independence result. The team decides.
13. **Problems found.** Anything odd in the code, data, prompts or gold during the task, with file and line.
14. **Files produced.** Every output path.

## 6. When done

Send Dhanush the report path and a 5-line summary: the chosen prompt, Haiku vs Qwen strict F1 with the interval,
tokens per posting for Qwen, projected days for 2,000 postings on the free tier, and the projected Haiku cost.
Then stop. **ASK** before starting the 2,000-posting batch.
