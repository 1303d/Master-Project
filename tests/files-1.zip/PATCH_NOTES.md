# Patches 2026-10-30: extract_skills.py and evaluate.py

Drop-in replacements for `src/evaluate.py` and `src/extract_skills.py`
(or apply `patches_2026-10-30.diff` with `git apply`).
Existing strict and lenient scores are unchanged: v3 and v5 dev runs re-scored to the same numbers.

## extract_skills.py
| Change | Why |
|---|---|
| Cache key now includes call settings (JSON hint, `--typed`, temperature, reasoning_format) | A typed and an untyped run of the same prompt could reuse each other's answers |
| `--legacy-cache-key` | Re-run v3/v5 from the old cache for free. A cached answer with a different JSON hint is refused (FAILED), never reused |
| Default `--postings` is `gold_postings_dev.csv`; test postings exit unless `--allow-test` | A plain run used to extract all 100 postings, test included |
| `--examples` needs `--examples-file`; test postings in it exit; dev gold postings print a warning | Few-shot examples used to come from dev gold v1 (with traits), tuning dev scores on dev labels |
| `--temperature` (default 0, as before; part of the cache key) | Lets you follow Groq's recommendation for reasoning models without losing old caches |

New-format cache keys mean the first run after the patch is a cache miss and pays for the calls again.
Use `--legacy-cache-key` only to reproduce runs made before the patch.

## evaluate.py
| Change | Why |
|---|---|
| `--split` default is `dev` | A plain run used to mix test postings into the score |
| `--same-postings-as RUN ...` | Scores only postings every run finished, so a failure in one run can't shift the comparison |
| `--baseline RUN` (+ `--bootstrap N`, default 2000) | Paired bootstrap: difference in F1 with a 95% interval, for strict, lenient and strict+alias |
| `--aliases skill_aliases_manual.csv` | Extra "strict+alias" column; strict and lenient untouched |
| `--sector-source split` | Sectors from `gold_split.csv` (the README said this; the code used `sector_fixed`) |
| Gold files without `sector_fixed` work | A dev-only gold export no longer needs the column added by hand |
| Report lists postings with gold skills but no predictions | #45 and #97 had none in both runs: check they are real empty answers |

## Example: the controlled comparison
```
py src/evaluate.py --model qwen/qwen3.8-27b --tag v8 --gold data/gold/gold_labels_v3.csv ^
   --baseline qwen_qwen3.8-27b_v3 --aliases data/skill_aliases_manual.csv --links data/processed/skill_links.csv
```
`--baseline` also limits both runs to the postings both finished.

## Before using the alias column
Check how `find_alias_candidates.py` built `skill_aliases_manual.csv`. If any candidates came from test
predictions or test gold labels, the alias column leaks test information into the final evaluation.
